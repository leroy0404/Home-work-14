#
# import json
# import requests
#
# response = requests.get("https://jsonplaceholder.typicode.com/todos/1")
# data = response.json()
#
# with open("data_from_website.json", "w") as file:
#     json.dump(data, file, indent=2)
#
# with open("data_from_website.json", "r") as file:
#     loaded_data = json.load(file)
#
# print("Данные из файла:")
# print(loaded_data)
#
#
# generated_data = [{"id": i, "title": f"Task {i}", "completed": False} for i in range(1, 101)]
#
# with open("generated_data.json", "w") as file:
#     json.dump(generated_data, file, indent=2)
#
# print("\nСгенерированные данные записаны в generated_data.json.")
#
#
# with open("generated_data.json", "r") as file:
#     loaded_generated_data = json.load(file)
#
# print("\nСгенерированные данные из файла:")
# print(loaded_generated_data)
#
# combined_data = loaded_generated_data + [loaded_data]
#
# with open("combined_data.json", "w") as file:
#     json.dump(combined_data, file, indent=2)
#
# print("\nОбъединенные данные записаны в combined_data.json.")

import json
import requests

response = requests.get("https://jsonplaceholder.typicode.com/todos/")
data = response.json()

with open("data_from_website.json", "w") as file:
    json.dump(data, file, indent=2)


with open("data_from_website.json", "r") as file:
    loaded_data = json.load(file)

print("Данные из файла:")
print(loaded_data)


for i, task in enumerate(loaded_data):
    filename = f"task_{i + 1}.json"
    with open(filename, "w") as file:
        json.dump(task, file, indent=2)
    print(f"Словарь {i + 1} записан в файл {filename}.")